Simple test
------------

Ensure your device works with this simple test.

.. literalinclude:: ../examples/motorkit_dc_motor_simpletest.py
    :caption: examples/motorkit_dc_motor_simpletest.py
    :linenos:

.. literalinclude:: ../examples/motorkit_stepper_simpletest.py
    :caption: examples/motorkit_stepper_simpletest.py
    :linenos:
