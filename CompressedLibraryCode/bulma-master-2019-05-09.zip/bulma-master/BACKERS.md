# Backers via Patreon

<div class="bd-content">
  <h2 class="title is-5">
    Documentation sponsors via Patreon ($500+)
  </h2>
  <table class="table is-bordered">
    <thead>
      <tr>
        <th>Name</th>
        <th>Twitter</th>
        <th>Website</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>Tipe</td>
        <td>
          <a href="https://twitter.com/tipeio" target="_blank" rel="nofollow">
          @tipeio
          </a>
        </td>
        <td>
        </td>
      </tr>
    </tbody>
  </table>
  <h2 class="title is-5">
    Homepage sponsors via Patreon ($100+)
  </h2>
  <table class="table is-bordered">
    <thead>
      <tr>
        <th>Name</th>
        <th>Twitter</th>
        <th>Website</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>Tooltwist</td>
        <td>
        </td>
        <td>
        </td>
      </tr>
      <tr>
        <td>Robert Bolder</td>
        <td>
        </td>
        <td>
        </td>
      </tr>
      <tr>
        <td>Phil Alves</td>
        <td>
          <a href="https://twitter.com/philalves01" target="_blank" rel="nofollow">
          @philalves01
          </a>
        </td>
        <td>
        </td>
      </tr>
      <tr>
        <td>HebergeurWeb.ca</td>
        <td>
        </td>
        <td>
        </td>
      </tr>
      <tr>
        <td>DontPayFull</td>
        <td>
        </td>
        <td>
        </td>
      </tr>
    </tbody>
  </table>
  <h2 class="title is-5">
    Generous backers via Patreon ($30+)
  </h2>
  <table class="table is-bordered">
    <thead>
      <tr>
        <th>Name</th>
        <th>Twitter</th>
        <th>Website</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>Nazar</td>
        <td>
          <a href="https://twitter.com/nazar_io" target="_blank" rel="nofollow">
          @nazar_io
          </a>
        </td>
        <td>
        </td>
      </tr>
      <tr>
        <td>Garry Newman</td>
        <td>
          <a href="https://twitter.com/garrynewman" target="_blank" rel="nofollow">
          @garrynewman
          </a>
        </td>
        <td>
        </td>
      </tr>
      <tr>
        <td>Adrian Ocneanu</td>
        <td>
          <a href="https://twitter.com/aocneanu" target="_blank" rel="nofollow">
          @aocneanu
          </a>
        </td>
        <td>
          <a href="https://www.earthlink.ro/" target="_blank" rel="nofollow">
          Earthlink
          </a>
        </td>
      </tr>
      <tr>
        <td>Aaron</td>
        <td>
          <a href="https://twitter.com/aequasi" target="_blank" rel="nofollow">
          @aequasi
          </a>
        </td>
        <td>
        </td>
      </tr>
    </tbody>
  </table>
  <h2 class="title is-5">
    Backers via Patreon ($10+)
  </h2>
  <table class="table is-bordered">
    <thead>
      <tr>
        <th>Name</th>
        <th>Twitter</th>
        <th>Website</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>Wikiki</td>
        <td>
        </td>
        <td>
        </td>
      </tr>
      <tr>
        <td>Tyler Weeres</td>
        <td>
          <a href="https://twitter.com/tweeres04" target="_blank" rel="nofollow">
          @tweeres04
          </a>
        </td>
        <td>
        </td>
      </tr>
      <tr>
        <td>Takayuki Yamaguchi</td>
        <td>
          <a href="https://twitter.com/takyam" target="_blank" rel="nofollow">
          @takyam
          </a>
        </td>
        <td>
        </td>
      </tr>
      <tr>
        <td>Stuart Stanfield</td>
        <td>
        </td>
        <td>
        </td>
      </tr>
      <tr>
        <td>Peter Ryszkiewicz</td>
        <td>
        </td>
        <td>
        </td>
      </tr>
      <tr>
        <td>Patrick Cool</td>
        <td>
        </td>
        <td>
        </td>
      </tr>
      <tr>
        <td>Leo Zeba</td>
        <td>
          <a href="https://twitter.com/leozeba" target="_blank" rel="nofollow">
          @leozeba
          </a>
        </td>
        <td>
        </td>
      </tr>
      <tr>
        <td>Jordan Nemrow</td>
        <td>
        </td>
        <td>
        </td>
      </tr>
      <tr>
        <td>Jason Seminara</td>
        <td>
        </td>
        <td>
        </td>
      </tr>
      <tr>
        <td>Franz Geffke</td>
        <td>
          <a href="https://twitter.com/f_anzs" target="_blank" rel="nofollow">
          @f_anzs
          </a>
        </td>
        <td>
        </td>
      </tr>
      <tr>
        <td>Dmitry Malyshev</td>
        <td>
        </td>
        <td>
        </td>
      </tr>
      <tr>
        <td>Charles Treece</td>
        <td>
          <a href="https://twitter.com/charlestreece" target="_blank" rel="nofollow">
          @charlestreece
          </a>
        </td>
        <td>
        </td>
      </tr>
    </tbody>
  </table>
</div>
