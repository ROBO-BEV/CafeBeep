**setup** is deployed to <https://deb.nodesource.com/setup>

**setup_dev** is deployed to <https://deb.nodesource.com/setup_dev>
